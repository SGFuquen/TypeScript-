const { Router } = require('express');
const { v4: uuid } = require('uuid');
const { readAll, writeAll } = require('../storage');

const router = Router();

router.get('/', async (_req, res) => {
  const items = await readAll();
  res.json(items);
});

router.get('/:id', async (req, res) => {
  const items = await readAll();
  const item = items.find(i => i.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Item no encontrado' });
  res.json(item);
});

router.post('/', async (req, res) => {
  const { name, price } = req.body || {};
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'name es requerido (string)' });
  }
  const item = {
    id: uuid(),
    name: name.trim(),
    price: Number(price) || 0,
    createdAt: new Date().toISOString()
  };
  const items = await readAll();
  items.push(item);
  await writeAll(items);
  res.status(201).json(item);
});

router.put('/:id', async (req, res) => {
  const { name, price } = req.body || {};
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'name es requerido (string)' });
  }
  const items = await readAll();
  const idx = items.findIndex(i => i.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Item no encontrado' });

  items[idx] = {
    ...items[idx],
    name: name.trim(),
    price: Number(price) || 0,
    updatedAt: new Date().toISOString()
  };
  await writeAll(items);
  res.json(items[idx]);
});

router.patch('/:id', async (req, res) => {
  const patch = req.body || {};
  const items = await readAll();
  const idx = items.findIndex(i => i.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Item no encontrado' });

  if ('name' in patch && (!patch.name || typeof patch.name !== 'string')) {
    return res.status(400).json({ error: 'name debe ser string no vacío' });
  }

  const next = { ...items[idx], ...patch, updatedAt: new Date().toISOString() };
  if ('price' in patch) next.price = Number(patch.price) || 0;

  items[idx] = next;
  await writeAll(items);
  res.json(items[idx]);
});

router.delete('/:id', async (req, res) => {
  const items = await readAll();
  const idx = items.findIndex(i => i.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Item no encontrado' });
  const [deleted] = items.splice(idx, 1);
  await writeAll(items);
  res.json({ ok: true, deleted });
});

module.exports = router;