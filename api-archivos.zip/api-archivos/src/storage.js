const fs = require('fs').promises;
const path = require('path');

const dataFile = path.join(__dirname, '..', 'data', 'items.json');

async function ensureFile() {
  try {
    await fs.mkdir(path.dirname(dataFile), { recursive: true });
    await fs.access(dataFile);
  } catch {
    await fs.writeFile(dataFile, '[]', 'utf8');
  }
}

async function readAll() {
  await ensureFile();
  const txt = await fs.readFile(dataFile, 'utf8');
  try {
    const data = JSON.parse(txt || '[]');
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

async function writeAll(items) {
  await ensureFile();
  const txt = JSON.stringify(items, null, 2);
  await fs.writeFile(dataFile, txt, 'utf8');
}

module.exports = { readAll, writeAll };