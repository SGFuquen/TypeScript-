const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const itemsRouter = require('./routes/items');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

app.get('/', (_req, res) => {
  res.json({ ok: true, name: 'API Archivos', version: '1.0.0' });
});

app.use('/api/items', itemsRouter);

app.use((req, res) => res.status(404).json({ error: 'Not Found' }));

app.listen(PORT, () => {
  console.log(`API escuchando en http://localhost:${PORT}`);
});